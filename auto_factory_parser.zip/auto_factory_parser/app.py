# app.py
# Streamlit 기반 자동차 공장 쿼리 파서 웹 애플리케이션

import streamlit as st
import json
import os
from datetime import datetime
from dotenv import load_dotenv
from parser import QueryParser

# 환경 변수 로드
load_dotenv()

# 페이지 설정
st.set_page_config(
    page_title="자동차 공장 쿼리 파서",
    page_icon="🏭",
    layout="wide",
    initial_sidebar_state="expanded"
)

# 세션 상태 초기화
if 'history' not in st.session_state:
    st.session_state.history = []

if 'parser' not in st.session_state:
    api_key = os.getenv("OPENAI_API_KEY")
    if api_key:
        st.session_state.parser = QueryParser(
            api_key=api_key,
            model="gpt-4o-mini",
            use_knowledge=True
        )
    else:
        st.session_state.parser = None


def format_json_display(data: dict) -> str:
    """JSON을 보기 좋게 포맷팅"""
    return json.dumps(data, indent=2, ensure_ascii=False)


def add_to_history(query: str, result: dict):
    """히스토리에 추가"""
    st.session_state.history.insert(0, {
        "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "query": query,
        "result": result
    })
    # 최대 20개까지만 저장
    if len(st.session_state.history) > 20:
        st.session_state.history = st.session_state.history[:20]


def main():
    """메인 애플리케이션"""
    
    # 헤더
    st.title("🏭 자동차 조립 공장 쿼리 파서")
    st.markdown("자연어 질의를 구조화된 JSON으로 변환합니다")
    
    # 사이드바
    with st.sidebar:
        st.header("⚙️ 설정")
        
        # API 키 확인
        if st.session_state.parser is None:
            st.error("❌ OPENAI_API_KEY가 설정되지 않았습니다")
            api_key_input = st.text_input(
                "OpenAI API Key",
                type="password",
                help=".env 파일에 OPENAI_API_KEY를 설정하거나 여기에 입력하세요"
            )
            if api_key_input:
                st.session_state.parser = QueryParser(
                    api_key=api_key_input,
                    model="gpt-4o-mini",
                    use_knowledge=True
                )
                st.success("✅ API 키가 설정되었습니다")
                st.rerun()
        else:
            st.success("✅ API 키 설정됨")
        
        st.divider()
        
        # 지식베이스 상태
        st.subheader("📚 지식베이스")
        if st.session_state.parser and st.session_state.parser.knowledge_loader:
            if st.session_state.parser.knowledge_loader.vectorstore:
                st.success("✅ 활성화")
            else:
                st.warning("⚠️ 문서 없음")
        else:
            st.info("ℹ️ 비활성화")
        
        st.divider()
        
        # 히스토리 관리
        st.subheader("📜 히스토리")
        st.write(f"총 {len(st.session_state.history)}개")
        
        if st.button("🗑️ 히스토리 삭제", use_container_width=True):
            st.session_state.history = []
            st.success("히스토리가 삭제되었습니다")
            st.rerun()
        
        st.divider()
        
        # 정보
        st.subheader("ℹ️ 정보")
        st.markdown("""
        **지원 기능:**
        - 시설/라인/장비 정보 추출
        - 시간 표현 정규화
        - 질의 의도 분류
        - 지식문서 참조
        - 파싱 신뢰도 평가
        """)
    
    # 메인 컨텐츠
    if st.session_state.parser is None:
        st.warning("⚠️ API 키를 설정해주세요 (사이드바 참조)")
        return
    
    # 입력 영역
    st.header("🔍 쿼리 입력")
    
    # 예시 쿼리 선택
    example_queries = [
        "사용자 정의 입력",
        "M16에서 어제 오후 5시 AA에서 KKK 하고 장비 6KBCDJD 에서 문제의 로그 찾아줘",
        "1라인 용접 로봇 3번 오늘 주간조에 알람 몇 번 났어?",
        "GV80 최종조립 라인 지난주 불량률 분석해줘",
        "울산공장 2라인 도장부스 컨베이어 지금 상태 어때?",
        "A조 야간에 AGV-012 충돌 사고 있었어?"
    ]
    
    selected_example = st.selectbox(
        "예시 쿼리 선택",
        example_queries,
        index=0
    )
    
    # 쿼리 입력
    if selected_example == "사용자 정의 입력":
        query = st.text_area(
            "자연어 쿼리를 입력하세요",
            height=100,
            placeholder="예: M16에서 어제 오후 5시 AA에서 KKK 하고 장비 6KBCDJD 에서 문제의 로그 찾아줘"
        )
    else:
        query = st.text_area(
            "자연어 쿼리를 입력하세요",
            value=selected_example,
            height=100
        )
    
    # 파싱 버튼
    col1, col2, col3 = st.columns([1, 1, 4])
    
    with col1:
        parse_button = st.button("🚀 파싱 실행", type="primary", use_container_width=True)
    
    with col2:
        clear_button = st.button("🔄 초기화", use_container_width=True)
    
    if clear_button:
        st.rerun()
    
    # 파싱 실행
    if parse_button:
        if not query.strip():
            st.error("❌ 쿼리를 입력해주세요")
        else:
            with st.spinner("파싱 중..."):
                result = st.session_state.parser.parse(query)
                add_to_history(query, result)
            
            st.divider()
            
            # 결과 표시
            if result["success"]:
                st.success("✅ 파싱 성공")
                
                # 메타 정보
                col1, col2 = st.columns(2)
                with col1:
                    st.metric(
                        "신뢰도",
                        f"{result['data'].get('confidence', 0):.2%}"
                    )
                with col2:
                    st.metric(
                        "지식베이스 사용",
                        "예" if result.get("context_used", False) else "아니오"
                    )
                
                # 주요 정보 표시
                st.subheader("📊 파싱 결과")
                
                data = result["data"]
                
                # 3단 레이아웃
                col1, col2, col3 = st.columns(3)
                
                with col1:
                    st.markdown("**🎯 질의 정보**")
                    st.write(f"**의도:** {data.get('intent', 'N/A')}")
                    st.write(f"**원본 쿼리:** {data.get('original_query', 'N/A')[:50]}...")
                
                with col2:
                    st.markdown("**🏭 시설 정보**")
                    st.write(f"**공장:** {data.get('plant') or 'N/A'}")
                    st.write(f"**라인:** {data.get('line') or 'N/A'}")
                    st.write(f"**스테이션:** {data.get('station') or 'N/A'}")
                    st.write(f"**구역:** {data.get('area') or 'N/A'}")
                
                with col3:
                    st.markdown("**⚙️ 장비 정보**")
                    st.write(f"**장비 ID:** {data.get('equipment_id') or 'N/A'}")
                    st.write(f"**장비 유형:** {data.get('equipment_type') or 'N/A'}")
                
                # 시간 정보
                if data.get('timestamp') or data.get('time_range') or data.get('shift'):
                    st.markdown("**⏰ 시간 정보**")
                    time_col1, time_col2, time_col3 = st.columns(3)
                    with time_col1:
                        st.write(f"**타임스탬프:** {data.get('timestamp') or 'N/A'}")
                    with time_col2:
                        time_range = data.get('time_range', {})
                        if time_range and (time_range.get('start') or time_range.get('end')):
                            st.write(f"**시작:** {time_range.get('start') or 'N/A'}")
                            st.write(f"**종료:** {time_range.get('end') or 'N/A'}")
                    with time_col3:
                        st.write(f"**교대조:** {data.get('shift') or 'N/A'}")
                
                # 문제 정보
                if data.get('issue_type') or data.get('severity'):
                    st.markdown("**⚠️ 문제 정보**")
                    issue_col1, issue_col2 = st.columns(2)
                    with issue_col1:
                        st.write(f"**문제 유형:** {data.get('issue_type') or 'N/A'}")
                    with issue_col2:
                        severity = data.get('severity')
                        if severity:
                            if severity == 'CRITICAL':
                                st.error(f"**심각도:** {severity}")
                            elif severity == 'HIGH':
                                st.warning(f"**심각도:** {severity}")
                            else:
                                st.info(f"**심각도:** {severity}")
                
                # 전체 JSON
                with st.expander("📄 전체 JSON 보기"):
                    st.code(format_json_display(data), language="json")
                
            else:
                st.error(f"❌ 파싱 실패: {result.get('error', '알 수 없는 오류')}")
    
    # 히스토리 표시
    if st.session_state.history:
        st.divider()
        st.header("📜 최근 파싱 히스토리")
        
        for i, item in enumerate(st.session_state.history[:5]):  # 최근 5개만 표시
            with st.expander(f"[{item['timestamp']}] {item['query'][:50]}..."):
                if item['result']['success']:
                    st.success("✅ 성공")
                    data = item['result']['data']
                    
                    # 간단한 정보만 표시
                    info_col1, info_col2 = st.columns(2)
                    with info_col1:
                        st.write(f"**의도:** {data.get('intent', 'N/A')}")
                        st.write(f"**신뢰도:** {data.get('confidence', 0):.2%}")
                    with info_col2:
                        st.write(f"**장비 ID:** {data.get('equipment_id') or 'N/A'}")
                        st.write(f"**문제 유형:** {data.get('issue_type') or 'N/A'}")
                    
                    with st.expander("전체 JSON"):
                        st.code(format_json_display(data), language="json")
                else:
                    st.error(f"❌ 실패: {item['result'].get('error', '알 수 없는 오류')}")


if __name__ == "__main__":
    main()
