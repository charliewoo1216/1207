#!/bin/bash

echo "==================================="
echo "자동차 공장 쿼리 파서 시작"
echo "==================================="
echo ""

# 가상환경 활성화 (있는 경우)
if [ -f "venv/bin/activate" ]; then
    echo "가상환경 활성화 중..."
    source venv/bin/activate
fi

# Streamlit 실행
echo "Streamlit 애플리케이션 실행 중..."
streamlit run app.py
