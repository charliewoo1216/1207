# knowledge_loader.py
# 지식문서를 로드하고 벡터 저장소를 구성하는 모듈

import os
from typing import List, Optional
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_community.vectorstores import FAISS
from langchain_openai import OpenAIEmbeddings
from langchain.docstore.document import Document


class KnowledgeLoader:
    """지식문서 로더 및 벡터 저장소 관리"""
    
    def __init__(self, knowledge_dir: str = "knowledge_docs"):
        """
        Args:
            knowledge_dir: 지식문서가 저장된 디렉토리 경로
        """
        self.knowledge_dir = knowledge_dir
        self.vectorstore = None
        self.embeddings = OpenAIEmbeddings()
        
    def load_documents(self) -> List[Document]:
        """지식문서 디렉토리에서 모든 텍스트 파일 로드"""
        documents = []
        
        if not os.path.exists(self.knowledge_dir):
            print(f"경고: {self.knowledge_dir} 디렉토리가 존재하지 않습니다.")
            return documents
        
        # 모든 .txt 파일 읽기
        for filename in os.listdir(self.knowledge_dir):
            if filename.endswith('.txt'):
                filepath = os.path.join(self.knowledge_dir, filename)
                try:
                    with open(filepath, 'r', encoding='utf-8') as f:
                        content = f.read()
                        doc = Document(
                            page_content=content,
                            metadata={"source": filename}
                        )
                        documents.append(doc)
                        print(f"✓ 문서 로드 완료: {filename}")
                except Exception as e:
                    print(f"✗ 문서 로드 실패 ({filename}): {e}")
        
        return documents
    
    def create_vectorstore(self, documents: List[Document]) -> Optional[FAISS]:
        """문서로부터 벡터 저장소 생성"""
        if not documents:
            print("경고: 로드된 문서가 없습니다.")
            return None
        
        # 텍스트 분할
        text_splitter = RecursiveCharacterTextSplitter(
            chunk_size=500,  # 청크 크기
            chunk_overlap=50,  # 청크 오버랩
            separators=["\n\n", "\n", " ", ""]
        )
        
        splits = text_splitter.split_documents(documents)
        print(f"✓ 문서 분할 완료: {len(splits)}개 청크")
        
        # FAISS 벡터 저장소 생성
        try:
            self.vectorstore = FAISS.from_documents(splits, self.embeddings)
            print("✓ 벡터 저장소 생성 완료")
            return self.vectorstore
        except Exception as e:
            print(f"✗ 벡터 저장소 생성 실패: {e}")
            return None
    
    def search_relevant_docs(self, query: str, k: int = 3) -> List[Document]:
        """쿼리와 관련된 문서 검색"""
        if self.vectorstore is None:
            print("경고: 벡터 저장소가 초기화되지 않았습니다.")
            return []
        
        try:
            docs = self.vectorstore.similarity_search(query, k=k)
            return docs
        except Exception as e:
            print(f"✗ 문서 검색 실패: {e}")
            return []
    
    def get_context_from_query(self, query: str, k: int = 3) -> str:
        """쿼리와 관련된 컨텍스트 문자열 반환"""
        docs = self.search_relevant_docs(query, k=k)
        
        if not docs:
            return ""
        
        context_parts = []
        for i, doc in enumerate(docs, 1):
            source = doc.metadata.get('source', 'Unknown')
            content = doc.page_content
            context_parts.append(f"[참고문서 {i} - {source}]\n{content}")
        
        return "\n\n".join(context_parts)
    
    def initialize(self) -> bool:
        """지식베이스 초기화"""
        print("=== 지식베이스 초기화 시작 ===")
        
        # 문서 로드
        documents = self.load_documents()
        
        if not documents:
            print("경고: 로드된 문서가 없습니다. 지식베이스 없이 진행합니다.")
            return False
        
        # 벡터 저장소 생성
        self.vectorstore = self.create_vectorstore(documents)
        
        if self.vectorstore is None:
            print("경고: 벡터 저장소 생성 실패")
            return False
        
        print("=== 지식베이스 초기화 완료 ===\n")
        return True


# 사용 예시
if __name__ == "__main__":
    loader = KnowledgeLoader()
    loader.initialize()
    
    # 테스트 쿼리
    test_query = "M16 스테이션"
    context = loader.get_context_from_query(test_query)
    print(f"\n테스트 쿼리: {test_query}")
    print(f"검색된 컨텍스트:\n{context}")
