import streamlit as st
import os
from dotenv import load_dotenv
import bs4
from langchain import hub
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_community.document_loaders import WebBaseLoader, TextLoader
from langchain_community.vectorstores import FAISS
from langchain_core.output_parsers import StrOutputParser
from langchain_core.runnables import RunnablePassthrough
from langchain_openai import ChatOpenAI, OpenAIEmbeddings
from langchain_core.prompts import PromptTemplate

# 환경 변수 로드
load_dotenv()

# 페이지 설정
st.set_page_config(
    page_title="민원상담 AI 챗봇",
    page_icon="💬",
    layout="centered"
)

# 제목 설정
st.title("💬 계양구청 전용 AI 챗봇")
st.caption("🚀 Powered by 계양구청 행정복지센터")

# RAG 관련 함수들
def load_document_from_file(file_path, encoding='utf-8'):
    """텍스트 파일에서 콘텐츠를 로드하는 함수"""
    loader = TextLoader(file_path, encoding=encoding)
    return loader.load()

def split_documents(docs, chunk_size=500, chunk_overlap=50):
    """문서를 청크로 분할하는 함수"""
    text_splitter = RecursiveCharacterTextSplitter(
        chunk_size=chunk_size, 
        chunk_overlap=chunk_overlap
    )
    return text_splitter.split_documents(docs)

def create_vectorstore(splits):
    """문서 청크로부터 벡터 저장소를 생성하는 함수"""
    return FAISS.from_documents(
        documents=splits, 
        embedding=OpenAIEmbeddings()
    )

def create_rag_chain():
    """사전 정의된 프롬프트로 RAG 체인을 생성하는 함수"""
    prompt = PromptTemplate.from_template(
        """당신은 질문-답변(Question-Answering)을 수행하는 친절한 AI 어시스턴트입니다. 당신의 임무는 주어진 문맥(context) 에서 주어진 질문(question) 에 답하는 것입니다.
        검색된 다음 문맥(context) 을 사용하여 질문(question) 에 답하세요. 만약, 주어진 문맥(context) 에서 답을 찾을 수 없다면, 답을 모른다면 `주어진 정보에서 질문에 대한 정보를 찾을 수 없습니다` 라고 답하세요.
        한글로 답변해 주세요. 단, 기술적인 용어나 이름은 번역하지 않고 그대로 사용해 주세요.

        #Question: 
        {question} 

        #Context: 
        {context} 

        #Answer:"""
    )
    
    llm = ChatOpenAI(model_name="gpt-4o-mini", temperature=0)
    
    return lambda retriever: (
        {"context": retriever, "question": RunnablePassthrough()}
        | prompt
        | llm
        | StrOutputParser()
    )

# 세션 상태 초기화
if 'rag_chain' not in st.session_state:
    try:
        # 문서 로드
        docs = load_document_from_file("data/sample-01.txt")
        
        # 문서 분할
        splits = split_documents(docs)
        
        # 벡터 저장소와 검색기 생성
        vectorstore = create_vectorstore(splits)
        retriever = vectorstore.as_retriever()
        
        # RAG 체인 생성
        st.session_state.rag_chain = create_rag_chain()(retriever)
        
    except Exception as e:
        st.error(f"초기화 중 오류가 발생했습니다: {str(e)}")

# 채팅 인터페이스
if 'messages' not in st.session_state:
    st.session_state.messages = []

# 이전 메시지 표시
for message in st.session_state.messages:
    with st.chat_message(message["role"]):
        st.markdown(message["content"])

# 사용자 입력 처리
if prompt := st.chat_input("무엇을 도와드릴까요?"):
    # 사용자 메시지 추가
    st.session_state.messages.append({"role": "user", "content": prompt})
    with st.chat_message("user"):
        st.markdown(prompt)

    # 어시스턴트 응답 생성
    with st.chat_message("assistant"):
        try:
            response = st.session_state.rag_chain.invoke(prompt)
            st.markdown(response)
            st.session_state.messages.append({"role": "assistant", "content": response})
        except Exception as e:
            error_message = f"답변 생성 중 오류가 발생했습니다: {str(e)}"
            st.error(error_message)
            st.session_state.messages.append({"role": "assistant", "content": error_message})

# 페이지 하단 추가 정보
st.markdown("---")
st.caption("© 2025 계양구청 행정복지센터. All rights reserved.")