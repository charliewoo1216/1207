# 자동차 조립 공장 쿼리 파서

자연어 질의를 구조화된 JSON으로 변환하는 AI 기반 쿼리 파서 시스템입니다.

## 주요 기능

- 🔍 **자연어 파싱**: 작업자의 자연어 질의를 구조화된 JSON으로 자동 변환
- 📚 **지식베이스 통합**: RAG(Retrieval-Augmented Generation) 기반 지식문서 참조
- 🎯 **의도 분류**: 검색, 분석, 비교, 요약 등 9가지 질의 의도 자동 분류
- ⏰ **시간 정규화**: 상대적 시간 표현을 절대 시간으로 자동 변환
- 📊 **신뢰도 평가**: 파싱 결과의 신뢰도를 0~1 사이 값으로 제공
- 🌐 **웹 인터페이스**: Streamlit 기반의 직관적인 사용자 인터페이스

## 시스템 구조

```
auto_factory_parser/
├── app.py                  # Streamlit 웹 애플리케이션
├── parser.py              # 쿼리 파싱 엔진
├── system_prompt.py       # LLM 시스템 프롬프트
├── knowledge_loader.py    # 지식문서 로더 (RAG)
├── requirements.txt       # Python 패키지 의존성
├── .env.example          # 환경 변수 템플릿
├── README.md             # 프로젝트 문서
└── knowledge_docs/       # 지식문서 디렉토리
    ├── equipment_codes.txt      # 장비 코드 매핑
    ├── process_guide.txt        # 공정 가이드
    └── facility_info.txt        # 시설 정보
```

## 설치 방법

### 1. 필수 요구사항

- Python 3.8 이상
- OpenAI API 키

### 2. 패키지 설치

```bash
# 가상환경 생성 (권장)
python -m venv venv

# 가상환경 활성화
# Windows:
venv\Scripts\activate
# macOS/Linux:
source venv/bin/activate

# 패키지 설치
pip install -r requirements.txt
```

### 3. 환경 변수 설정

```bash
# .env.example을 .env로 복사
cp .env.example .env

# .env 파일을 열어서 API 키 입력
# OPENAI_API_KEY=your-actual-api-key-here
```

## 사용 방법

### 웹 인터페이스 실행

```bash
streamlit run app.py
```

브라우저가 자동으로 열리며 `http://localhost:8501`에서 애플리케이션을 사용할 수 있습니다.

### Python 코드에서 직접 사용

```python
from parser import QueryParser
import os

# 파서 초기화
api_key = os.getenv("OPENAI_API_KEY")
parser = QueryParser(api_key=api_key, use_knowledge=True)

# 쿼리 파싱
query = "M16에서 어제 오후 5시 AA에서 KKK 하고 장비 6KBCDJD 에서 문제의 로그 찾아줘"
result = parser.parse(query)

if result["success"]:
    print(result["data"])
else:
    print(f"오류: {result['error']}")
```

## 지식베이스 구성

`knowledge_docs/` 디렉토리에 `.txt` 파일을 추가하여 지식베이스를 구축할 수 있습니다.

### 예시 파일 구조

**equipment_codes.txt:**
```
M16: 차체용접 스테이션 16번
AA: 조립라인 A 구역
6KBCDJD: 용접 로봇 장비 ID
```

**process_guide.txt:**
```
KKK: 최종 품질 검사 공정
차체용접: 차체 프레임을 용접하는 공정
최종조립: 모든 부품을 조립하는 최종 공정
```

**facility_info.txt:**
```
울산공장: 현대자동차 울산 제1공장
LINE1: 주 생산 라인 1번
LINE2: 주 생산 라인 2번
```

## 파싱 결과 예시

### 입력 쿼리
```
M16에서 어제 오후 5시 AA에서 KKK 하고 장비 6KBCDJD 에서 문제의 로그 찾아줘
```

### 출력 JSON
```json
{
  "intent": "SEARCH",
  "plant": null,
  "line": null,
  "station": "M16",
  "area": "AA",
  "equipment_id": "6KBCDJD",
  "equipment_type": null,
  "timestamp": "2025-12-06T17:00:00+09:00",
  "time_range": null,
  "shift": "EVENING",
  "process": "KKK",
  "model": null,
  "vin": null,
  "lot_number": null,
  "work_order": null,
  "part_number": null,
  "issue_type": "ERROR",
  "severity": null,
  "operator_id": null,
  "team": null,
  "keywords": ["문제", "로그"],
  "original_query": "M16에서 어제 오후 5시 AA에서 KKK 하고 장비 6KBCDJD 에서 문제의 로그 찾아줘",
  "confidence": 0.92
}
```

## 지원되는 질의 의도 (Intent)

1. **SEARCH**: 로그/데이터 검색
2. **ANALYZE**: 분석 요청
3. **COMPARE**: 비교
4. **SUMMARIZE**: 요약
5. **ALERT**: 알림 확인
6. **TREND**: 트렌드 조회
7. **ROOT_CAUSE**: 근본 원인 분석
8. **STATUS**: 상태 조회
9. **PREDICT**: 예측

## 지원되는 문제 유형 (Issue Type)

- **ERROR**: 장비 에러
- **ALARM**: 알람 발생
- **WARNING**: 경고
- **DEFECT**: 품질 불량
- **DOWNTIME**: 라인 정지
- **MALFUNCTION**: 오작동
- **SAFETY**: 안전 이슈
- **QUALITY**: 품질 이슈
- **MAINTENANCE**: 유지보수
- **DELAY**: 생산 지연

## 기술 스택

- **Frontend**: Streamlit
- **LLM**: OpenAI GPT-4o-mini
- **Framework**: LangChain
- **Vector DB**: FAISS
- **Embeddings**: OpenAI Embeddings

## 커스터마이징

### 시스템 프롬프트 수정

`system_prompt.py` 파일에서 시스템 프롬프트를 수정하여 도메인에 맞게 조정할 수 있습니다.

### 모델 변경

`parser.py`의 `QueryParser` 클래스에서 모델을 변경할 수 있습니다:

```python
parser = QueryParser(
    api_key=api_key,
    model="gpt-4",  # gpt-4, gpt-4o, gpt-4o-mini 등
    use_knowledge=True
)
```

## 트러블슈팅

### OpenAI API 오류
- API 키가 올바른지 확인
- API 사용량 한도를 확인
- 네트워크 연결 상태 확인

### 지식베이스 로드 실패
- `knowledge_docs/` 디렉토리가 존재하는지 확인
- `.txt` 파일이 UTF-8 인코딩인지 확인
- 파일 권한 확인

### JSON 파싱 오류
- GPT 모델의 temperature를 낮춰보세요 (현재 0.1)
- 시스템 프롬프트에서 JSON 출력 형식을 더 명확히 지정

## 라이선스

MIT License

## 문의

문제가 발생하거나 개선 사항이 있다면 이슈를 등록해주세요.

## 버전 히스토리

- **v1.0.0** (2025-12-07)
  - 초기 릴리스
  - 기본 쿼리 파싱 기능
  - RAG 지식베이스 통합
  - Streamlit 웹 인터페이스
