import os
from dotenv import load_dotenv
import bs4
from langchain import hub
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_community.document_loaders import WebBaseLoader, TextLoader
from langchain_community.vectorstores import FAISS
from langchain_core.output_parsers import StrOutputParser
from langchain_core.runnables import RunnablePassthrough
from langchain_openai import ChatOpenAI, OpenAIEmbeddings
from langchain_core.prompts import PromptTemplate

# 환경 변수 로드
load_dotenv()

def load_document_from_web(url):
    """웹 URL에서 콘텐츠를 로드하는 함수"""
    loader = WebBaseLoader(
        web_paths=(url,),
        bs_kwargs=dict(
            parse_only=bs4.SoupStrainer(
                "div",
                attrs={"class": ["newsct_article _article_body", "media_end_head_title"]},
            )
        ),
    )
    return loader.load()

def load_document_from_file(file_path, encoding='utf-8'):
    """텍스트 파일에서 콘텐츠를 로드하는 함수"""
    loader = TextLoader(file_path, encoding=encoding)
    return loader.load()

def split_documents(docs, chunk_size=500, chunk_overlap=50):
    """문서를 청크로 분할하는 함수
    
    Args:
        docs: 분할할 문서
        chunk_size: 각 청크의 크기 (기본값: 500)
        chunk_overlap: 청크 간 중복되는 문자 수 (기본값: 50)
    """
    text_splitter = RecursiveCharacterTextSplitter(
        chunk_size=chunk_size, 
        chunk_overlap=chunk_overlap
    )
    return text_splitter.split_documents(docs)

def create_vectorstore(splits):
    """문서 청크로부터 벡터 저장소를 생성하는 함수
    
    Args:
        splits: 분할된 문서 청크들
    """
    return FAISS.from_documents(
        documents=splits, 
        embedding=OpenAIEmbeddings()
    )

def create_rag_chain():
    """사전 정의된 프롬프트로 RAG 체인을 생성하는 함수"""
    prompt = PromptTemplate.from_template(
        """당신은 질문-답변(Question-Answering)을 수행하는 친절한 AI 어시스턴트입니다. 당신의 임무는 주어진 문맥(context) 에서 주어진 질문(question) 에 답하는 것입니다.
        검색된 다음 문맥(context) 을 사용하여 질문(question) 에 답하세요. 만약, 주어진 문맥(context) 에서 답을 찾을 수 없다면, 답을 모른다면 `자세한 내용은, 이메일 또는 전화번호 070 8831 7162 를 통하여, 전문 상담의 진행 부탁합니다.` 라고 답하세요.
        한글로 답변해 주세요. 단, 기술적인 용어나 이름은 번역하지 않고 그대로 사용해 주세요. 마크다운, 문장부호는 제거하고 150자이내로 답변

        #Question: 
        {question} 

        #Context: 
        {context} 

        #Answer:"""
    )

    # GPT-4 모델을 temperature 0으로 초기화 (더 일관된 응답을 위해)
    llm = ChatOpenAI(model_name="gpt-4o-mini", temperature=0.5)
    
    return lambda retriever: (
        {"context": retriever, "question": RunnablePassthrough()}
        | prompt
        | llm
        | StrOutputParser()
    )

def main():
    """메인 실행 함수"""
    try:
        # 1. 문서 로드 (웹 또는 파일에서)
        # 웹 콘텐츠의 경우:
        # docs = load_document_from_web("https://blog.naver.com/wemeet-ai/223810823377")
        
        # 파일 콘텐츠의 경우:
        docs = load_document_from_file("data/myagent.txt")
        print(f"문서 {len(docs)}개를 로드했습니다")
        
        # 2. 문서 분할
        splits = split_documents(docs)
        print(f"문서를 {len(splits)}개의 청크로 분할했습니다")
        
        # 3. 벡터 저장소와 검색기 생성
        vectorstore = create_vectorstore(splits)
        retriever = vectorstore.as_retriever()
        
        # 4. RAG 체인 생성 및 사용
        rag_chain = create_rag_chain()(retriever)
        
        # 5. 예시 질문들
        questions = [
            "도입시 장점은?"
          #  "비즈링에서 가장 좋은 기능은?",
          #  "도입방법은?"
        ]
        
        # 6. 답변 생성
        for question in questions:
            print(f"\n질문: {question}")
            answer = rag_chain.invoke(question)
            print(f"답변: {answer}")
            
    except Exception as e:
        print(f"오류가 발생했습니다: {str(e)}")

if __name__ == "__main__":
    main()