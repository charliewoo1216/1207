# parser.py
# 자연어 쿼리를 JSON으로 파싱하는 모듈

import json
from typing import Dict, Optional
from langchain_openai import ChatOpenAI
from langchain.prompts import ChatPromptTemplate
from langchain.schema import HumanMessage, SystemMessage
from system_prompt import get_system_prompt
from knowledge_loader import KnowledgeLoader


class QueryParser:
    """자연어 쿼리 파서"""
    
    def __init__(self, api_key: str, model: str = "gpt-4o-mini", use_knowledge: bool = True):
        """
        Args:
            api_key: OpenAI API 키
            model: 사용할 GPT 모델
            use_knowledge: 지식문서 사용 여부
        """
        self.llm = ChatOpenAI(
            api_key=api_key,
            model=model,
            temperature=0.1,  # 낮은 temperature로 일관된 파싱
            max_tokens=1000
        )
        self.system_prompt = get_system_prompt()
        self.use_knowledge = use_knowledge
        self.knowledge_loader = None
        
        # 지식베이스 초기화
        if self.use_knowledge:
            self.knowledge_loader = KnowledgeLoader()
            self.knowledge_loader.initialize()
    
    def parse(self, query: str) -> Dict:
        """
        자연어 쿼리를 JSON으로 파싱
        
        Args:
            query: 사용자의 자연어 쿼리
            
        Returns:
            파싱된 JSON 딕셔너리
        """
        try:
            # 지식문서에서 관련 컨텍스트 가져오기
            context = ""
            if self.use_knowledge and self.knowledge_loader and self.knowledge_loader.vectorstore:
                context = self.knowledge_loader.get_context_from_query(query, k=2)
            
            # 프롬프트 구성
            messages = [
                SystemMessage(content=self.system_prompt)
            ]
            
            # 컨텍스트가 있으면 추가
            if context:
                user_content = f"""다음 지식문서를 참고하여 쿼리를 파싱하세요:

{context}

---

사용자 쿼리: {query}"""
            else:
                user_content = f"사용자 쿼리: {query}"
            
            messages.append(HumanMessage(content=user_content))
            
            # LLM 호출
            response = self.llm.invoke(messages)
            response_text = response.content.strip()
            
            # JSON 파싱 (마크다운 코드 블록 제거)
            if response_text.startswith("```json"):
                response_text = response_text[7:]
            if response_text.startswith("```"):
                response_text = response_text[3:]
            if response_text.endswith("```"):
                response_text = response_text[:-3]
            
            response_text = response_text.strip()
            
            # JSON 파싱
            parsed_result = json.loads(response_text)
            
            return {
                "success": True,
                "data": parsed_result,
                "error": None,
                "context_used": bool(context)
            }
            
        except json.JSONDecodeError as e:
            return {
                "success": False,
                "data": None,
                "error": f"JSON 파싱 오류: {str(e)}\n응답: {response_text[:200]}",
                "context_used": False
            }
        except Exception as e:
            return {
                "success": False,
                "data": None,
                "error": f"파싱 오류: {str(e)}",
                "context_used": False
            }
    
    def batch_parse(self, queries: list) -> list:
        """여러 쿼리를 배치로 파싱"""
        results = []
        for query in queries:
            result = self.parse(query)
            results.append({
                "query": query,
                "result": result
            })
        return results


# 사용 예시
if __name__ == "__main__":
    import os
    from dotenv import load_dotenv
    
    # 환경 변수 로드
    load_dotenv()
    api_key = os.getenv("OPENAI_API_KEY")
    
    if not api_key:
        print("오류: OPENAI_API_KEY 환경 변수를 설정해주세요.")
        exit(1)
    
    # 파서 초기화
    parser = QueryParser(api_key=api_key, use_knowledge=True)
    
    # 테스트 쿼리
    test_queries = [
        "M16에서 어제 오후 5시 AA에서 KKK 하고 장비 6KBCDJD 에서 문제의 로그 찾아줘",
        "1라인 용접 로봇 3번 오늘 주간조에 알람 몇 번 났어?",
        "GV80 최종조립 라인 지난주 불량률 분석해줘"
    ]
    
    print("=== 쿼리 파싱 테스트 ===\n")
    
    for i, query in enumerate(test_queries, 1):
        print(f"[테스트 {i}] {query}")
        result = parser.parse(query)
        
        if result["success"]:
            print("✓ 파싱 성공")
            print(f"컨텍스트 사용: {'예' if result['context_used'] else '아니오'}")
            print(json.dumps(result["data"], indent=2, ensure_ascii=False))
        else:
            print(f"✗ 파싱 실패: {result['error']}")
        
        print("\n" + "="*50 + "\n")
