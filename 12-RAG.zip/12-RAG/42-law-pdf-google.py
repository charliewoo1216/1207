from dotenv import load_dotenv
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_community.document_loaders import PyMuPDFLoader
from langchain_community.vectorstores import FAISS
from langchain_core.output_parsers import StrOutputParser
from langchain_core.runnables import RunnablePassthrough
from langchain_core.prompts import PromptTemplate
from langchain_google_genai import GoogleGenerativeAI  # Gemini 모델
from langchain_google_genai import GoogleGenerativeAIEmbeddings  # Gemini 임베딩


## pip install langchain-google-genai

class RAGPipeline:
    """RAG (Retrieval Augmented Generation) 파이프라인 구현 클래스"""
    
    def __init__(self, pdf_path: str):
        """
        RAG 파이프라인 초기화
        
        Args:
            pdf_path (str): PDF 파일 경로
        """
        # API 키 로드
        load_dotenv()
        
        # PDF 문서 로드
        self.docs = PyMuPDFLoader(pdf_path).load()
        print(f"문서의 페이지수: {len(self.docs)}")
        
        # 문서 분할 설정
        self.text_splitter = RecursiveCharacterTextSplitter(
            chunk_size=500,
            chunk_overlap=50
        )
        
        # 벡터 저장소 및 검색기 초기화
        self._initialize_vectorstore()
        
        # 프롬프트 템플릿 설정
        self.prompt = PromptTemplate.from_template(
            """You are an assistant for question-answering tasks. 
Use the following pieces of retrieved context to answer the question. 
If you don't know the answer, just say that you don't know. 
Answer in Korean.

#Context: 
{context}

#Question:
{question}

#Answer:"""
        )
        
        # Gemini 모델 초기화
        self.llm = GoogleGenerativeAI(
            model="gemini-pro",
            temperature=0
        )
        
        # RAG 체인 구성
        self._setup_chain()

    def _initialize_vectorstore(self):
        """벡터 저장소 및 검색기 초기화"""
        # 문서 분할
        split_documents = self.text_splitter.split_documents(self.docs)
        print(f"분할된 청크의수: {len(split_documents)}")
        
        # Gemini 임베딩 생성 및 벡터 저장소 초기화
        embeddings = GoogleGenerativeAIEmbeddings(model="models/embedding-001")
        self.vectorstore = FAISS.from_documents(
            documents=split_documents, 
            embedding=embeddings
        )
        
        # 검색기 생성
        self.retriever = self.vectorstore.as_retriever()

    def _setup_chain(self):
        """RAG 체인 설정"""
        self.chain = (
            {"context": self.retriever, "question": RunnablePassthrough()}
            | self.prompt
            | self.llm
            | StrOutputParser()
        )

    def answer_question(self, question: str) -> str:
        """
        질문에 대한 답변 생성
        
        Args:
            question (str): 사용자 질문
            
        Returns:
            str: 생성된 답변
        """
        return self.chain.invoke(question)

def main():
    """메인 실행 함수"""
    # RAG 파이프라인 초기화
    rag = RAGPipeline("data/SPRI_AI_Brief_2023년12월호_F.pdf")
    
    # 예시 질문에 대한 답변 생성
    question = "삼성전자가 자체 개발한 AI의 이름은?"
    answer = rag.answer_question(question)
    
    print(f"\n질문: {question}")
    print(f"답변: {answer}")

if __name__ == "__main__":
    main()