from pathlib import Path
from typing import List
import os
from dotenv import load_dotenv
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_community.document_loaders import (
    PyMuPDFLoader,
    TextLoader,
    Docx2txtLoader,
    UnstructuredPowerPointLoader,
    CSVLoader,
    UnstructuredExcelLoader,
    UnstructuredMarkdownLoader
)
from langchain_community.vectorstores import FAISS
from langchain_core.documents import Document
from langchain_core.output_parsers import StrOutputParser
from langchain_core.runnables import RunnablePassthrough
from langchain_core.prompts import PromptTemplate
from langchain_google_genai import GoogleGenerativeAI
from langchain_google_genai import GoogleGenerativeAIEmbeddings

class MultiDocumentLoader:
    """다양한 형식의 문서를 로드하는 클래스"""
    
    # 파일 확장자별 로더 매핑
    LOADER_MAPPING = {
        ".pdf": PyMuPDFLoader,
        ".txt": TextLoader,
        ".docx": Docx2txtLoader,
        ".doc": Docx2txtLoader,
        ".pptx": UnstructuredPowerPointLoader,
        ".ppt": UnstructuredPowerPointLoader,
        ".csv": CSVLoader,
        ".xlsx": UnstructuredExcelLoader,
        ".xls": UnstructuredExcelLoader,
        ".md": UnstructuredMarkdownLoader
    }
    
    @classmethod
    def load_documents(cls, directory_path: str) -> List[Document]:
        """
        디렉토리에서 지원되는 모든 문서를 로드
        
        Args:
            directory_path (str): 문서가 있는 디렉토리 경로
            
        Returns:
            List[Document]: 로드된 문서 리스트
        """
        documents = []
        directory = Path(directory_path)
        
        if not directory.exists():
            raise FileNotFoundError(f"디렉토리를 찾을 수 없습니다: {directory_path}")
        
        # 디렉토리의 모든 파일을 재귀적으로 처리
        for file_path in directory.rglob("*"):
            if file_path.is_file():
                ext = file_path.suffix.lower()
                if ext in cls.LOADER_MAPPING:
                    try:
                        loader = cls.LOADER_MAPPING[ext](str(file_path))
                        loaded_docs = loader.load()
                        print(f"로드됨: {file_path} (문서 수: {len(loaded_docs)})")
                        documents.extend(loaded_docs)
                    except Exception as e:
                        print(f"경고: {file_path} 로드 중 오류 발생 - {str(e)}")
        
        return documents

class RAGPipeline:
    """RAG (Retrieval Augmented Generation) 파이프라인 구현 클래스"""
    
    def __init__(self, directory_path: str):
        """
        RAG 파이프라인 초기화
        
        Args:
            directory_path (str): 문서가 있는 디렉토리 경로
        """
        # API 키 로드
        load_dotenv()
        
        # 문서 로드
        print(f"\n문서 로딩 시작: {directory_path}")
        self.docs = MultiDocumentLoader.load_documents(directory_path)
        print(f"총 로드된 문서 수: {len(self.docs)}")
        
        # 문서 분할 설정
        self.text_splitter = RecursiveCharacterTextSplitter(
            chunk_size=1000,
            chunk_overlap=200,
            separators=["\n\n", "\n", ".", "!", "?", ",", " ", ""]
        )
        
        # 벡터 저장소 및 검색기 초기화
        self._initialize_vectorstore()
        
        # 프롬프트 템플릿 설정
        self.prompt = PromptTemplate.from_template(
            """다음 문맥을 바탕으로 질문에 답변해주세요.
답변은 반드시 주어진 문맥에서 찾아야 합니다.
문맥에 답이 없다면 "주어진 문서에서 답을 찾을 수 없습니다"라고 답변하세요.

#문맥:
{context}

#질문:
{question}

#답변:"""
        )
        
        # Gemini 모델 초기화
        self.llm = GoogleGenerativeAI(
            model="gemini-2.0-flash-lite-preview-02-05",
            temperature=0
        )
        
        # RAG 체인 구성
        self._setup_chain()

    def _initialize_vectorstore(self):
        """벡터 저장소 및 검색기 초기화"""
        # 문서 분할
        split_documents = self.text_splitter.split_documents(self.docs)
        print(f"분할된 청크의수: {len(split_documents)}")
        
        # 임베딩 생성 및 벡터 저장소 초기화
        embeddings = GoogleGenerativeAIEmbeddings(model="models/embedding-001")
        self.vectorstore = FAISS.from_documents(
            documents=split_documents, 
            embedding=embeddings
        )
        
        # 검색기 생성
        self.retriever = self.vectorstore.as_retriever(
            search_type="similarity",
            search_kwargs={"k": 4}
        )

    def _setup_chain(self):
        """RAG 체인 설정"""
        self.chain = (
            {"context": self.retriever, "question": RunnablePassthrough()}
            | self.prompt
            | self.llm
            | StrOutputParser()
        )

    def answer_question(self, question: str) -> str:
        """
        질문에 대한 답변 생성
        
        Args:
            question (str): 사용자 질문
            
        Returns:
            str: 생성된 답변
        """
        try:
            # 검색된 문서 확인
            print("\n검색된 문서 내용:")
            docs = self.retriever.invoke(question)
            for i, doc in enumerate(docs, 1):
                print(f"\n문서 {i} (출처: {doc.metadata.get('source', '알 수 없음')}):")
                print("-" * 50)
                print(doc.page_content)
                print("-" * 50)
            
            # 답변 생성
            return self.chain.invoke(question)
            
        except Exception as e:
            print(f"답변 생성 중 오류 발생: {str(e)}")
            return "죄송합니다. 답변을 생성하는 중에 오류가 발생했습니다."

def main():
    """메인 실행 함수"""
    try:
        # RAG 파이프라인 초기화
        rag = RAGPipeline("data3")
        
        # 예시 질문에 대한 답변 생성
        question = "양사가 계약한 총 계약금액은?"
        answer = rag.answer_question(question)
        
        print(f"\n질문: {question}")
        print(f"답변: {answer}")
        
    except Exception as e:
        print(f"오류 발생: {str(e)}")

if __name__ == "__main__":
    main()


### pip install docx2txt unstructured python-pptx openpyxl