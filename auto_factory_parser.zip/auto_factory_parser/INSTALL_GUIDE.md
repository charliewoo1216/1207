# 설치 및 실행 가이드

## 1. 시스템 요구사항

- Python 3.8 이상
- 인터넷 연결 (OpenAI API 사용)
- 최소 2GB RAM
- 최소 500MB 디스크 공간

## 2. 설치 단계

### 2.1 Python 설치 확인

```bash
python --version
```

Python이 설치되어 있지 않다면, https://www.python.org/downloads/ 에서 다운로드하세요.

### 2.2 프로젝트 압축 해제

다운로드한 `auto_factory_parser.zip` 파일을 원하는 위치에 압축 해제합니다.

### 2.3 가상환경 생성 (권장)

#### Windows
```bash
cd auto_factory_parser
python -m venv venv
venv\Scripts\activate
```

#### Linux/Mac
```bash
cd auto_factory_parser
python3 -m venv venv
source venv/bin/activate
```

### 2.4 패키지 설치

```bash
pip install -r requirements.txt
```

설치 시간은 약 3-5분 소요됩니다.

### 2.5 환경 변수 설정

1. `.env.example` 파일을 `.env`로 복사합니다.

#### Windows
```bash
copy .env.example .env
```

#### Linux/Mac
```bash
cp .env.example .env
```

2. `.env` 파일을 텍스트 에디터로 열어서 OpenAI API 키를 입력합니다.

```
OPENAI_API_KEY=sk-your-actual-api-key-here
```

**OpenAI API 키 발급 방법:**
1. https://platform.openai.com/ 접속
2. 회원가입 또는 로그인
3. API Keys 메뉴 선택
4. "Create new secret key" 클릭
5. 생성된 키를 복사하여 .env 파일에 붙여넣기

## 3. 실행 방법

### 방법 1: 실행 스크립트 사용 (권장)

#### Windows
`run.bat` 파일을 더블클릭하거나 명령 프롬프트에서:
```bash
run.bat
```

#### Linux/Mac
터미널에서:
```bash
./run.sh
```

### 방법 2: 직접 명령어 입력

```bash
streamlit run app.py
```

## 4. 웹 브라우저 접속

실행하면 자동으로 웹 브라우저가 열립니다. 
자동으로 열리지 않으면 브라우저에서 다음 주소로 접속하세요:

```
http://localhost:8501
```

## 5. 사용 방법

### 5.1 기본 사용

1. 웹 인터페이스에서 쿼리 입력란에 자연어로 질의 입력
2. "파싱 실행" 버튼 클릭
3. 파싱 결과 확인

### 5.2 예시 쿼리 사용

화면의 "예시 쿼리 선택" 드롭다운에서 예시를 선택하여 테스트할 수 있습니다.

### 5.3 지식베이스 활용

`knowledge_docs/` 디렉토리에 `.txt` 파일을 추가하면 자동으로 지식베이스에 포함됩니다.

#### 지식문서 추가 방법:
1. `knowledge_docs/` 폴더에 `.txt` 파일 생성
2. UTF-8 인코딩으로 저장
3. 애플리케이션 재시작

## 6. 문제 해결

### 6.1 "ModuleNotFoundError" 오류
```bash
pip install -r requirements.txt
```
패키지를 다시 설치하세요.

### 6.2 "OpenAI API 키 오류"
- `.env` 파일에 올바른 API 키가 설정되어 있는지 확인
- API 키에 공백이나 따옴표가 없는지 확인
- OpenAI 계정에 크레딧이 있는지 확인

### 6.3 "포트가 이미 사용 중" 오류
다른 포트로 실행:
```bash
streamlit run app.py --server.port 8502
```

### 6.4 한글이 깨져 보이는 경우
- 터미널 인코딩을 UTF-8로 설정
- Windows: `chcp 65001` 실행 후 재시작

### 6.5 지식베이스 로드 실패
- `knowledge_docs/` 폴더가 존재하는지 확인
- `.txt` 파일이 UTF-8 인코딩인지 확인
- 파일 권한 확인

## 7. 종료 방법

### 웹 애플리케이션 종료
- 터미널에서 `Ctrl + C` 입력
- 또는 터미널 창 닫기

## 8. 업데이트

새 버전으로 업데이트 시:

1. 기존 파일 백업 (특히 `.env` 파일과 `knowledge_docs/` 폴더)
2. 새 버전 압축 해제
3. `.env` 파일과 지식문서 복원
4. 패키지 재설치:
```bash
pip install -r requirements.txt --upgrade
```

## 9. 성능 최적화 팁

1. **API 호출 최소화**: 
   - 동일한 쿼리는 히스토리에서 확인
   - 배치 처리 활용

2. **지식베이스 최적화**:
   - 불필요한 문서 제거
   - 문서는 명확하고 간결하게 작성

3. **모델 선택**:
   - 빠른 응답: `gpt-4o-mini` (기본값)
   - 높은 정확도: `gpt-4o`

## 10. 추가 리소스

- OpenAI API 문서: https://platform.openai.com/docs
- Streamlit 문서: https://docs.streamlit.io
- LangChain 문서: https://python.langchain.com

## 11. 지원

문제가 발생하면 다음 정보와 함께 문의하세요:
- Python 버전
- 운영체제 및 버전
- 오류 메시지 전체
- 실행 로그
