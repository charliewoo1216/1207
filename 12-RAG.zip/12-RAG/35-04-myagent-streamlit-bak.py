import streamlit as st
import os
from dotenv import load_dotenv
import bs4
from langchain import hub
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_community.document_loaders import WebBaseLoader, TextLoader
from langchain_community.vectorstores import FAISS
from langchain_core.output_parsers import StrOutputParser
from langchain_core.runnables import RunnablePassthrough
from langchain_openai import ChatOpenAI, OpenAIEmbeddings
from langchain_core.prompts import PromptTemplate

# 현재 실행 파일 기준 절대 경로 설정
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(BASE_DIR, "data")

# 환경 변수 로드
load_dotenv()

# 페이지 설정
st.set_page_config(
    page_title="MyAgent - FAQ(데모용)",
    page_icon="💬",
    layout="centered"
)

# Hide the menu button (three dots in upper right)
hide_menu_style = """
        <style>
        #MainMenu {visibility: hidden;}
        .stDeployButton {display:none;}
        footer {visibility: hidden;}
        header {visibility: hidden;}
        </style>
        """
st.markdown(hide_menu_style, unsafe_allow_html=True)

# 제목 설정
st.title("💬 MyAgent 솔루션 (상담챗봇)")

# 세션 상태에 선택된 질문 추가
if 'selected_question' not in st.session_state:
    st.session_state.selected_question = ""

# 자주 묻는 질문 버튼 섹션 추가
st.markdown("##### AI 전화상담 : 📞 070-4522-2831")

# 버튼 스타일 사용자 정의
button_style = """
<style>
    div[data-testid="stHorizontalBlock"] > div:nth-child(1) button,
    div[data-testid="stHorizontalBlock"] > div:nth-child(2) button,
    div[data-testid="stHorizontalBlock"] > div:nth-child(3) button {
        width: 100%;
        border: 1px solid #e0e0e0;
        background-color: #f0f2f6;
        padding: 10px;
        border-radius: 8px;
        text-align: left;
    }
    div[data-testid="stHorizontalBlock"] > div button:hover {
        background-color: #e0e0e0;
        border-color: #c0c0c0;
    }
</style>
"""
st.markdown(button_style, unsafe_allow_html=True)

# 질문 버튼 생성
col1, col2, col3 = st.columns(3)

# 질문 버튼 클릭 핸들러
def set_question(question):
    st.session_state.selected_question = question
    
with col1:
    st.button("MyAgent가 무엇인가요?", key="question1", on_click=set_question, args=("MyAgent가 무엇인가요?",))
    
with col2:
    st.button("어떤 방식으로 제공되나요?", key="question2", on_click=set_question, args=("어떤 방식으로 제공되나요?",))
    
with col3:
    st.button("어떤 이점이 있나요?", key="question3", on_click=set_question, args=("어떤 이점이 있나요?",))

st.caption("질문 버튼을 클릭하거나 직접 질문을 입력해주세요.")

# RAG 관련 함수들
def load_document_from_file(file_path, encoding='utf-8'):
    """텍스트 파일에서 콘텐츠를 로드하는 함수"""
    loader = TextLoader(file_path, encoding=encoding)
    return loader.load()

def split_documents(docs, chunk_size=500, chunk_overlap=50):
    """문서를 청크로 분할하는 함수"""
    text_splitter = RecursiveCharacterTextSplitter(
        chunk_size=chunk_size, 
        chunk_overlap=chunk_overlap
    )
    return text_splitter.split_documents(docs)

def create_vectorstore(splits):
    """문서 청크로부터 벡터 저장소를 생성하는 함수"""
    return FAISS.from_documents(
        documents=splits, 
        embedding=OpenAIEmbeddings()
    )

def create_rag_chain():
    """사전 정의된 프롬프트로 RAG 체인을 생성하는 함수"""
    prompt = PromptTemplate.from_template(
        """당신은 질문-답변(Question-Answering)을 수행하는 친절한 AI 어시스턴트입니다. 당신의 임무는 주어진 문맥(context) 에서 주어진 질문(question) 에 답하는 것입니다.
        검색된 다음 문맥(context) 을 사용하여 질문(question) 에 답하세요. 만약, 주어진 문맥(context) 에서 답을 찾을 수 없다면, 답을 모른다면 `자세한 내용은, 이메일 또는 전화번호 070 8831 7162 를 통하여, 전문 상담의 진행 부탁합니다.` 라고 답하세요.
        한글로 답변해 주세요. 단, 기술적인 용어나 이름은 번역하지 않고 그대로 사용해 주세요. 마크다운, 문장부호는 제거하고 150자이내로 답변
        #Question: 
        {question} 
        #Context: 
        {context} 
        #Answer:"""
    )
    
    llm = ChatOpenAI(model_name="gpt-4o-mini", temperature=0.4)
    
    return lambda retriever: (
        {"context": retriever, "question": RunnablePassthrough()}
        | prompt
        | llm
        | StrOutputParser()
    )

# 세션 상태 초기화
if 'rag_chain' not in st.session_state:
    try:
        # 문서 로드 - 절대 경로 사용
        docs = load_document_from_file(os.path.join(DATA_DIR, "myagent.txt"))
        
        # 문서 분할
        splits = split_documents(docs)
        
        # 벡터 저장소와 검색기 생성
        vectorstore = create_vectorstore(splits)
        retriever = vectorstore.as_retriever()
        
        # RAG 체인 생성
        st.session_state.rag_chain = create_rag_chain()(retriever)
        
    except Exception as e:
        st.error(f"초기화 중 오류가 발생했습니다: {str(e)}")

# 채팅 인터페이스
if 'messages' not in st.session_state:
    st.session_state.messages = []

# 이전 메시지 표시
for message in st.session_state.messages:
    with st.chat_message(message["role"]):
        st.markdown(message["content"])

# 버튼 클릭으로 선택된 질문 처리
if st.session_state.selected_question:
    prompt = st.session_state.selected_question
    st.session_state.selected_question = ""  # 질문 처리 후 초기화
    
    # 사용자 메시지 추가
    st.session_state.messages.append({"role": "user", "content": prompt})
    with st.chat_message("user"):
        st.markdown(prompt)
    
    # 어시스턴트 응답 생성
    with st.chat_message("assistant"):
        try:
            response = st.session_state.rag_chain.invoke(prompt)
            st.markdown(response)
            st.session_state.messages.append({"role": "assistant", "content": response})
        except Exception as e:
            error_message = f"답변 생성 중 오류가 발생했습니다: {str(e)}"
            st.error(error_message)
            st.session_state.messages.append({"role": "assistant", "content": error_message})
    
    # 페이지 새로고침하여 처리된 질문과 응답 표시
    st.rerun()

# 사용자 입력 처리 (기존 방식)
if prompt := st.chat_input("무엇을 도와드릴까요?"):
    # 사용자 메시지 추가
    st.session_state.messages.append({"role": "user", "content": prompt})
    with st.chat_message("user"):
        st.markdown(prompt)
    
    # 어시스턴트 응답 생성
    with st.chat_message("assistant"):
        try:
            response = st.session_state.rag_chain.invoke(prompt)
            st.markdown(response)
            st.session_state.messages.append({"role": "assistant", "content": response})
        except Exception as e:
            error_message = f"답변 생성 중 오류가 발생했습니다: {str(e)}"
            st.error(error_message)
            st.session_state.messages.append({"role": "assistant", "content": error_message})

# 페이지 하단 추가 정보
st.markdown("---")
st.caption("© 2025 WeMeet-AI. All rights reserved.")